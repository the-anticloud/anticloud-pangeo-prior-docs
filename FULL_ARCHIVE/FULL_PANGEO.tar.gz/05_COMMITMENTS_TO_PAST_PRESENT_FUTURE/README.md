# 05 Commitments To Past Present Future

**Project:** PANGEO
**Upstream:** https://github.com/pangeo-data/pangeo

Content specific to PANGEO in category ACADEMIA_RD.
