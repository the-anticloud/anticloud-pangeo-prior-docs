# 18 Command Line Interface

**Project:** PANGEO
**Upstream:** https://github.com/pangeo-data/pangeo

Content specific to PANGEO in category ACADEMIA_RD.
