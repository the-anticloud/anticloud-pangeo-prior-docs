.. _meeting-notes:

Meeting Schedule and Notes
==========================

Community Meeting
-----------------

Pangeo holds weekly community meetings every Wednesday.  The meetings alternate between 12PM and 4PM US Eastern Time to encourage 
participants from a wider range of time zones.  Anyone may attend!

Most meetings September-June will begin with a  :ref:`Pangeo-Showcase` talk, 
followed by discussion, optional check-ins, and any agenda items.   In July-August the Showcase Talks take a holiday break, but the Weekly Meeting still takes place! 

The :ref:`Pangeo-Showcase` talks are 15 minutes, recorded and receive a DOI.

The check-ins are an opportunity for anyone to meet other members of the Pangeo community and let them know what
you are working on with short, one minute updates, and agenda items are anything people feel would benefit from group discussion.

* Schedule: Every Wednesday, alternating between 12pm ET and 4pm ET (See the Calendar at the bottom of this page!) 
* Conferencing: `Zoom <https://numfocus-org.zoom.us/j/83234473026?pwd=mgM3uAuru1AE1aFPlRjW2dAAAyo8IY.1>`__
* Notes:  `Google Doc <https://docs.google.com/document/d/e/2PACX-1vRerhoxG-wOvh-wQTj7F8HPYve75l8pAtL-tgtzY_3YLqVUsaMSEgE4K70HgMt5S91FMwSu8EIizewy/pub>`_

Continental Community Meetings
------------------------------

To adress different time zones among the globe continental meetings have been organized.

1. Europe & Africa

   Discord: `Invite to join <https://discord.gg/ex5qqEyyTz>`__ 

   - Pangeo European Coffee ; an informal meeting with open discussions:   
      * Schedule: Every week on Tuesday at 9:30am CET
      * Conferencing: https://numfocus-org.zoom.us/j/81977735338?pwd=pVM3UvnSAJORc2p4Oad39TESPvBzV5.1
      * Notes: `Google Doc <https://docs.google.com/document/d/1Vq1ljPRQYWF_u0Ku1eEhQyYreijAJ2QW6FELdIsiYDs/edit?usp=sharing>`__

2. Oceania

   - Monthly meeting: 
      * Schedule: 3rd Friday of every month at 1pm Australian Eastern Time  
      * Conferencing: `Zoom <https://anu.zoom.us/j/82147791120?pwd=Q2U2Q1N1UWkwdWlnTGdTSVdrck04QT09>`__
      * Notes: `Google Doc <https://bit.ly/Pangeo-Oceania-minutes>`__

Working Group Meetings
----------------------

1. Machine Learning Working Group
    * Schedule: First Tuesday of the month at 3p ET
    * Conferencing:  `Zoom <https://us02web.zoom.us/j/86595617140?pwd=aEZJeEtPZ2dmcjRmVkhnVUVWOEZOZz09>`__
    * Notes: `Dropbox doc <https://paper.dropbox.com/doc/Meeting-notes-Machine-Learning-WG--AmU~wZXwdbpTZi8rQsJQH9_sAg-9UUgyywF9jmIMXXbmZTyJ>`__
2. Cloud Operations Working Group
    * Schedule: Second Monday of the month at 11:30a ET
    * Conferencing: `whereby.com/pangeo <https://whereby.com/pangeo>`_
    * Notes: `Google Doc <https://docs.google.com/document/d/1I-2VNNHoAjjeYvlCezQhFLmiu2OevqGDS5nUAP-6Hfw/edit?usp=sharing>`__
3. `Project Pythia <https://projectpythia.org>`_ (formerly the Education Working Group)
    * Schedule: Mondays at 3p US Eastern Time (alternating between Project Pythia Education and Infrastructure Working Groups)
    * Conferencing: `Zoom <https://ucar-edu.zoom.us/j/91375487587>`__ (consult the `Pythia Calendar <https://calendar.google.com/calendar/u/0?cid=Y180cXB2ZjMxNmFmZDltdjBjaTdkMnVpYWZvZ0Bncm91cC5jYWxlbmRhci5nb29nbGUuY29t>`_ for how to join)
    * Notes: `link <https://docs.google.com/document/d/e/2PACX-1vQN5YFkZtCZPKVk2Rte2xoHuiqJuYz1KpynsSKmeCLwP-4glUsGuCPJbITwB4OJc8dOhUpHAMacdx59/pub>`__
4. Pangeo Forge (Cloud Data Platform)
    * `Project Roadmap <https://github.com/pangeo-forge/roadmap>`_
    * Schedule: Every other Monday at 2pm ET
    * Conferencing: `whereby.com/pangeo <https://whereby.com/pangeo>`_
    * Notes: `Google Doc <https://docs.google.com/document/d/14FpI9vaM6TeFtmM7LP9o_d5DZaYKgQVTTzT7tFRt-Nw/edit#heading=h.rdvtuxpqyxy>`__
5. Open Science Meeting - discussions to coordinate open science activities 
    * Schedule: First Friday of each month at 5pm CET
    * Conferencing: `whereby.com/pangeo <https://whereby.com/pangeo>`_
    * Notes: `Google Doc <https://docs.google.com/document/d/1mMDlFblBOeEmHnhaZZfgaMJvuzpw28ro3uyJngeY_jk/edit>`__
6. Distributed Array Computing Working Group
    * Schedule: Every Other Monday at 1pm ET
    * Conferencing: `Zoom <https://columbiauniversity.zoom.us/j/99521529645?pwd=YzhIbDlhZUE1dUNvR2R4SzV5VVBhQT09>`_
    * `Forum Post <https://discourse.pangeo.io/t/new-working-group-for-distributed-array-computing/2734>`_

Past working groups include the `Data Working Group <https://docs.google.com/document/d/e/2PACX-1vTP1iV4YJcHznwcfUwlLoEDVPdgtD9iAXql73vn4uAotOQMVh9R8vTIKxPHnvnrijX1C24T5aJJZ95x/pub>`_
and the `Education Working Group <https://github.com/pangeo-data/education-material>`_.

Meetings Calendar
-----------------

A Google Calendar has been setup with these reoccurring times [GCAL_, ICAL_].

.. _GCAL: https://calendar.google.com/calendar/embed?src=ucar.edu_c23ln4014khs3f65o93vqv5kqc%40group.calendar.google.com&ctz=America%2FLos_Angeles
.. _ICAL: https://calendar.google.com/calendar/ical/ucar.edu_c23ln4014khs3f65o93vqv5kqc%40group.calendar.google.com/public/basic.ics

.. raw:: html

    <iframe src="https://calendar.google.com/calendar/b/1/embed?title=Upcoming%20Pangeo%20Meetings&amp;showPrint=0&amp;showTabs=0&amp;showCalendars=0&amp;mode=AGENDA&amp;height=300&amp;wkst=1&amp;bgcolor=%23FFFFFF&amp;src=ucar.edu_c23ln4014khs3f65o93vqv5kqc%40group.calendar.google.com&amp;color=%23711616&amp;ctz=America%2FLos_Angeles" style="border-width:0" width="800" height="300" frameborder="0" scrolling="no"></iframe>
